//Licence
//SPDX-License-Identifier: LGPL-3.0-only

//Version
pragma solidity 0.8.24;

//Contract

contract CryptoBank2 {

uint256 maxBalance;
address public owner;

mapping (address => uint256) public userBalance;

modifier onlyOwner{
    require(owner == msg.sender, "You are not allowed");
    _;
}

constructor (address owner_,uint256 maxBalance_){
    owner= owner_;
    maxBalance = maxBalance_;
}

function depositEther() external payable onlyOwner{
    require(userBalance[msg.sender] + msg.value <= 5000000000000000000, "MaxBalance reached");
    userBalance[msg.sender] += msg.value;
}

function withdrawEther (uint256 amount_) external onlyOwner{    
    
    userBalance[msg.sender]-=amount_;
}





}
