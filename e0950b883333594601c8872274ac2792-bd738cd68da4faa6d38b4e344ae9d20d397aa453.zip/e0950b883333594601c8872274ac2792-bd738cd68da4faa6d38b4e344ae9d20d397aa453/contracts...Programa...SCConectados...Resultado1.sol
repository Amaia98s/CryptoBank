//Licencia
//SPDX-License-Identifier: LGPL-3.0-only

//Version solidity
pragma solidity 0.8.24;

//Contrato

contract Resultado1{
 
    uint256 public resultado;

    function setResultado (uint256 num_) external {
        resultado = num_;
    }



}