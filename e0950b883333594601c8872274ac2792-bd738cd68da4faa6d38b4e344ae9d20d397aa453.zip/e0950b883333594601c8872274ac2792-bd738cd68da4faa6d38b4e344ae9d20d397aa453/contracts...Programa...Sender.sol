//Licencia
//SPDX-License-Identifier: LGPL-3.0-only

//Version solidity
pragma solidity 0.8.24;

//Contrato

contract Sender {

    address public owner;

    constructor(){
        owner = msg.sender;
    }



}