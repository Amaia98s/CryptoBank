//Licencia
//SPDX-License-Identifier: LGPL-3.0-only

//Version solidity
pragma solidity 0.8.24;

import "./interfaces/IResultado2.sol";
//Contrato

contract Sumador2{

    address public resultado;
   
    constructor (address resultado_){
        resultado = resultado_;
     
        
    }

    function addition (uint256 num1_, uint256 num2_) external{
        uint256 resultado_ = num1_ + num2_;
        IResultado2(resultado).setResultado(resultado_);
    }

     function setFee(uint256 newFee_) external{
        IResultado2(resultado).setFee(newFee_);
     }
}