//Licencia
//SPDX-License-Identifier: LGPL-3.0-only

//Version solidity
pragma solidity 0.8.24;

//Contrato
contract Calculadora {

    //Variables
    uint256 public resultado = 10;

    //Modifier
    modifier chechknumber (uint256 num1_) {
        if (num1_ != 10) revert();
        _;
    }

    //Events
    event Addition (uint256 number1, uint256 number2, uint256 resultado);
    event Substraction(uint256 number1,uint256 number2, uint256 resultado);

    //ExternalFunctions
    function addition (uint256 num1_, uint256 num2_) public returns (uint256 resultado_)
    {
        resultado_ = num1_ + num2_;
        emit Addition(num1_, num2_, resultado);
    }


     function substraction (uint256 num1_, uint256 num2_) public returns (uint256 resultado_)
    {
        resultado_ = substraction_logic(num1_, num2_);
        emit Substraction(num1_,num2_,resultado);
    }

    function substraction2 (int256 num1_, int256 num2_) public pure  returns (int256 resultado_)
    {
        resultado_ =  substraction_logic2(num1_,num2_);
    }


     function multiplier (uint256 num1_) public{
        resultado = resultado * num1_;
    }

     function multiplier2 (uint256 num1_) public chechknumber(num1_){
        resultado = resultado* num1_;
    }

    //INternalFunctions
    function substraction_logic(uint256 num1_, uint256 num2_) pure  internal returns (uint256 resultado_){
        resultado_ = num1_ - num2_;
    }

    function substraction_logic2(int256 num1_, int256 num2_) pure  internal returns (int256 resultado_){
        resultado_ = num1_ - num2_;
    }
}