//Licencia
//SPDX-License-Identifier: LGPL-3.0-only

//Version solidity
pragma solidity 0.8.24;

//Contrato

contract PayableContractV2  {

function sendEther () public payable{


}

function withDrwaEther(uint256 amount) public{
//recipent +call +valor ether + datos

(bool success,) = msg.sender.call{value:amount}("");
require(success,"Transfer failed");
}
}