//Licencia
//SPDX-License-Identifier: LGPL-3.0-only

//Version solidity
pragma solidity 0.8.24;

error SenderNotAdmin(address);

//Contrato

contract RequireTest{

    address public admin;

    constructor (address admin_){
        admin =admin_;
    }

//Function + if: msg.sender sea igual a admin

    function checkAdmin() public view {
        if(msg.sender != admin) revert();
    }


//Function + require: msg.sender sea igual a admin

    function checkAdminRequire() public view{
        require(msg.sender == admin,"Msg.sender is not admin");
    }

//Function + if + customerror: msg.sender sea igual a admin 

function checkAdminCustomError() public view{
    if(msg.sender != admin) revert SenderNotAdmin (msg.sender);
}
}